# Python codes

### How to compare machine learning classifiers in 2 lines of code (lazypredict Python library)

Watch the video [How to compare machine learning classifiers in 2 lines of code (lazypredict Python library)](https://youtu.be/ZdDUwlwJNi0) to see the use of lazypredict in action.

<a href="https://youtu.be/ZdDUwlwJNi0"><img src="http://img.youtube.com/vi/ZdDUwlwJNi0/0.jpg" alt="How to compare machine learning classifiers in 2 lines of code (lazypredict Python library)" width="400" /></a>

---

### Vaex - Fast data frame for Data Science (Handle billion rows in seconds)

Watch the video [Vaex - Fast data frame for Data Science (Handle billion rows in seconds)](https://youtu.be/inGjY4cds3Q) to see the use of lazypredict in action.

<a href="https://youtu.be/inGjY4cds3Q"><img src="http://img.youtube.com/vi/inGjY4cds3Q/0.jpg" alt="Vaex - Fast data frame for Data Science (Handle billion rows in seconds)" width="400" /></a>

